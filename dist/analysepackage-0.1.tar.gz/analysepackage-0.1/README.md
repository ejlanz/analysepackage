# analysepackage
This library was created for the EDSA Analyse Hackathon and contains sorting and recursion functions

## building this package locally
'python setup.py sdist'

## installing this package from Github
'pip install git+https://github.com/ejlanz/analaysepackage'

## updating this package from Github
'pip install --upgrade git+https://github.com/ejlanz/analaysepackage'
